package com.green.mapper;

import java.util.List;

import com.green.domain.BoardVO;
import com.green.domain.Criteria;

public interface BoardMapper {
	public List<BoardVO> getList();
	public void insert(BoardVO board);
	public Integer insertSelectKey(BoardVO board);
	public BoardVO read(Long bno);
	public int delete(Long bno);
	public int update(BoardVO board);
	
	public List<BoardVO> getListWithPaging(Criteria crit);
	

}
