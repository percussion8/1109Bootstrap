package com.green.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.green.domain.BoardVO;
import com.green.domain.Criteria;
import com.green.domain.PageDTO;
import com.green.service.BoardService;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@RequestMapping("/board/*")
@AllArgsConstructor
public class BoardController {
	//서비스 주입
	private BoardService service; //교재 213상단에 적혀있음 ,AllArg~~,또는 setter
	
	@GetMapping("/list")
	public void list(Criteria crit, Model model) {
		log.info("컨트롤러에서 list " + crit);
		model.addAttribute("list", service.getList(crit));
		model.addAttribute("pageMaker", new PageDTO(crit, 123));
	}
	
	@GetMapping("/register")
	public String register1() {//board 폴더 1.jsp
		 
		return "/board/register";
	}
	
	@PostMapping("/register")
	public String register(BoardVO board, RedirectAttributes rttr) {
		log.info("컨틀롤러에서 등록 " +  board);
		service.register(board);//추가 
		rttr.addFlashAttribute("result" ,board.getBno());//1회용 저장 
		return "redirect:/board/list";//교재 216, response.sendRidirect호출
	}
	@GetMapping({"/get", "/modify"}) //교재 218
	public void get(@RequestParam("bno") Long bno, Model model) {
		log.info("컨틀롤러에서의 /get");
		model.addAttribute("board", service.get(bno));
	}
	
	@PostMapping("modify") //post 방식의 수정
	public String modify(BoardVO board , RedirectAttributes rttr) {
		log.info("컨트롤러에서의 수정 "+ board);
		if(service.modify(board)) { //성공하면 
			rttr.addFlashAttribute("result", "success");
		}
		return "redirect:/board/list";//list에서 result에 success정보를 가지고 있음
	}
	@PostMapping("remove") //post방식의 삭제 
	public String remove(@RequestParam("bno") Long bno, 
				RedirectAttributes rttr) {
		log.info("컨트롤러에서의 삭제 "+ bno);
		if(service.remove(bno)) {
			rttr.addFlashAttribute("result", "success");
		}
		return "redirect:/board/list";
	}
}
